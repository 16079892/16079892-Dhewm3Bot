#!/usr/bin/env python3

import botbasic, time, sys, os
import botlib
from chvec import *
import math
import random


debugTowards = True
maxWeapons = 10
gridUnit = 12 * 4 #  chisel unit is 4 feet
healthy = 0
pistol_ammo_count = 0
shotgun_ammo_count = 0
holdingShotgun = False
holdingPistol = False
noMoreShotgunAmmo = False
noMorePistolAmmo = False
noMoreAmmo = False
detectedCheck = False

#
#  printf - keeps C programmers happy :-)
#

def printf (format, *args):
    print(str(format) % args, end=' ')

def sqr (x):
    return x * x

def is_close_doom3 (position1, position2):
    print ("is_close: ", end="")
    print (position1, position2)
    diff = subVec (position1, position2)
    hypot = math.sqrt (sqr (diff[0]) + sqr (diff[1]))
    print ("  result: ", hypot)
    return hypot <= gridUnit * 2

def is_close_doom3_detect (position1, position2):
    print ("is_close: ", end="")
    print (position1, position2)
    diff = subVec (position1, position2)
    hypot = math.sqrt (sqr (diff[0]) + sqr (diff[1]))
    print ("  result: ", hypot)
    return hypot <= gridUnit * 6

#
#  move_towards - move bot towards position, pos.
#                 pos is penguin tower coordinates.
#

def move_towards (pos, velocity):
    global detectedCheck
    bot.reset ()
    dist = bot.calcnav_pos (pos)
    if dist is None:
        if debugTowards:
            print ("cannot reach", pos, "bot moving randomly")
            quit () # remove this once test is complete
        bot.turn (random.randint (-90, 90), 1)
        bot.select (["turn"])
        bot.forward (velocity, velocity)
        bot.select (["move"])
    else:
        if debugTowards:
            print("distance according to dijkstra is", dist)
        bot.journey_pos (velocity, dist, pos)
        if debugTowards:
            print("finished my journey to", pos)
            print("  I'm at", bot.d2pv (bot.getpos (me)))

def moveTowards (bot, you):
    bot.reset ()
    print("will go and find", you)
    print("I'm currently at", bot.getpos (me), "and", you, "is at", bot.getpos (you))
    ### b.face_position (b.getpos (you))
    ### return b
    dest = bot.d2pv (bot.getpos (you))
    if debugTowards:
        print("bot is at", bot.d2pv (bot.getpos (me)))
        print("dest is at", dest)
    while not is_close_doom3 (bot.getpos (me), bot.getpos (you)):
        if healthCheck () != 100:
            return bot
            
        elif detection (bot, you) == True:
            return bot
            
        dest = bot.d2pv (bot.getpos (you))
        d = bot.calcnav (you)
        if debugTowards:
            print("object", you, "is", d, "units away at pen coord", dest)
        if d is None:
            if debugTowards:
                print("cannot reach, randomly moving", you)
            # do something and move elsewhere
            bot.turn (random.randint (-90, 90), 1)
            bot.select (["turn"])
            bot.forward (100, random.randint (8, 12))
            bot.select (["move"])
            return bot
        else:
            if debugTowards:
                print("distance according to dijkstra is", d)
            bot.journey (100, d, bot.d2pv (bot.getpos (you)), you)
            if debugTowards:
                print("finished journey (...", you, ")")
                print("  result is that I'm currently at", bot.getpos (me), "and", you, "is at", bot.getpos (you))
                print("      penguin tower coords I'm at", bot.d2pv (bot.getpos (me)), "and", you, "is at", dest)
    # and face the object
    bot.face (you)
    return bot
    
def moveTowardsNoChecks (bot, you):
    bot.reset ()
    print("will go and find", you)
    print("I'm currently at", bot.getpos (me), "and", you, "is at", bot.getpos (you))
    ### b.face_position (b.getpos (you))
    ### return b
    dest = bot.d2pv (bot.getpos (you))
    if debugTowards:
        print("bot is at", bot.d2pv (bot.getpos (me)))
        print("dest is at", dest)
    while not is_close_doom3 (bot.getpos (me), bot.getpos (you)):            
        dest = bot.d2pv (bot.getpos (you))
        d = bot.calcnav (you)
        if debugTowards:
            print("object", you, "is", d, "units away at pen coord", dest)
        if d is None:
            if debugTowards:
                print("cannot reach, randomly moving", you)
            # do something and move elsewhere
            bot.turn (random.randint (-90, 90), 1)
            bot.select (["turn"])
            bot.forward (100, random.randint (8, 12))
            bot.select (["move"])
            return bot
        else:
            if debugTowards:
                print("distance according to dijkstra is", d)
            bot.journey (100, d, bot.d2pv (bot.getpos (you)), you)
            if debugTowards:
                print("finished journey (...", you, ")")
                print("  result is that I'm currently at", bot.getpos (me), "and", you, "is at", bot.getpos (you))
                print("      penguin tower coords I'm at", bot.d2pv (bot.getpos (me)), "and", you, "is at", dest)
    # and face the object
    bot.face (you)
    return bot    

def findYou ():
    for i in bot.allobj ():
        if i != bot.me ():
            return i
    
def walk_fire (bot, you):
    bot.reset ()
    bot = moveTowardsNoChecks (bot, you)
    bot.face (you)
    bot.select (['move'])  # wait until bot has stopped moving
    goVisible ()
    bot.startFiring ()
    #goInvisible ()
    bot.face (you)
    bot.select (['move'])  # wait the crouch and fire single round to finish
    bot.select (['fire'])
    bot.stopFiring ()    

def goInvisible ():
    bot.setvisibilityshader ("pulse/melt/model/player")
    bot.visibilityFlag (True)
    bot.visibilityParams ([3, 3])
    bot.flipVisibility ()
    bot.setvisibilityshader ("melt/model/player/green/body2inv")  # all players entities use disappear
    bot.setvisibilityshader ("melt/model/player/green/head2inv", ["player2_head"])  #  change the head entity
    #bot.visibilityParams ([2])   # run visibility effects for a duration of .. seconds
    #bot.visibilityFlag (True)    # turn on the visibility flag for all player entities.
    #bot.flipVisibility ()        # now release all the above info to the renderer

def goVisible ():
    bot.visibilityFlag (False)    # turn on the visibility flag for all player entities.
    bot.flipVisibility ()

def weaponInventory ():
    holding_weapons = []
    for weapon in range (0, maxWeapons):
        if bot.inventoryWeapon (weapon):
            holding_weapons += [weapon]
    return holding_weapons

def weaponExamples ():
    printf ("bot has the following weapons: ")
    print (weaponInventory ())
    printf ("\n")
    printf ("bot has the following ammo: ")
    print (ammoInventory ())
    printf ("\n")
    for weapon in weaponInventory ():
        bot.changeWeapon (weapon)
        time.sleep (3)
        bot.dropWeapon ()
        time.sleep (3)

def visit_label (bot, label_list, visited_labels):
    visible_labels = []
    for label in label_list:
        bot.reset ()  # is this necessary?
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        if bot.isvisible (label_entity_no):
            visible_labels += [[label, label_entity_no]]
        if not (label in visited_labels):
            visited_labels[label] = [[label, label_entity_no, 0]]
            print ("moving towards a label:", label)
            bot = moveTowards (bot, label_entity_no)
            return bot, False, visited_labels
    return bot, True, visited_labels


def execBot (bot, useExceptions = True):
    if useExceptions:
        try:
            botMain (bot)
        except:
            print ("bot was killed, or script terminated")
            return
    else:
        botMain (bot)

def healthCheck ():
    global healthy
    bot.reset ()
    healthy = bot.health ()
    return healthy    

def patrolling (bot, you):
    """
    label_list = bot.get_label_list ()  # obtains a list of label names from the pen map
    print ("bot has found these labels in the map:", label_list)
    visited_labels = {}
    finished = False
    while not finished:
        if healthCheck () != 100:
            break
        bot, finished, visited_labels = visit_label (bot, label_list, visited_labels)
        print ("bot has found these labels in the map:", label_list)
        if healthCheck () != 100:
            break"""
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check1 = "A"
        check2 = "B"
        check3 = "C"
        check4 = "D"
        if label != check1 and label != check2 and label != check3 and label != check4:
            print ("label matches check!")
            if healthCheck () != 100:
                break
            elif detection (bot, you) == True:
                break
            bot = moveTowards (bot, label_entity_no)
            print ("Moving towards pistol ammo!")
            if healthCheck () != 100:
                break
            elif detection (bot, you) == True:
                break
           
def reload ():
    bot.reloadWeapon ()
    #bot.select (['reload'])

def get_pistol_ammo (bot):
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "B"
        if label == check:
            print ("label matches check!")
            bot = moveTowardsNoChecks (bot, label_entity_no)
            print ("Moving towards pistol ammo!")
            break

def get_pistol (bot):
    global pistol_ammo_count
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "A"
        if label == check:
            print ("label matches check!")
            bot = moveTowardsNoChecks (bot, label_entity_no)
            print ("Moving towards pistol ammo!")
            pistol_ammo_count = 0
            break
    
def get_shotgun (bot):
    global shotgun_ammo_count
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "C"
        if label == check:
            print ("label matches check!")
            bot = moveTowardsNoChecks (bot, label_entity_no)
            print ("Moving towards shotgun!")
            shotgun_ammo_count = 0
            break
    
def get_shotgun_ammo (bot):
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "D"
        if label == check:
            print ("label matches check!")
            bot = moveTowardsNoChecks (bot, label_entity_no)
            print ("Moving towards shotgun ammo!")
            break

def fire_guns (bot, you):
    global pistol_ammo_count, shotgun_ammo_count, holdingShotgun, holdingPistol
    
    if shotgun_ammo_count < 8:
        bot.changeWeapon (2)
        holdingShotgun = True
        holdingPistol = False
        walk_fire (bot, you)
        shotgun_ammo_count += 1
        print ("shotgun_ammo_count = ", shotgun_ammo_count)
        return True
            
    elif pistol_ammo_count < 12:
        bot.changeWeapon (1)
        holdingShotgun = False
        holdingPistol = True
        walk_fire (bot,you)
        pistol_ammo_count += 1
        print ("pistol_ammo_count = ", pistol_ammo_count)
        return True
            
    else:
        return False
    
def gun_reload_or_change ():
    global holdingShotgun, holdingPistol, noMoreShotgunAmmo, noMorePistolAmmo, noMoreAmmo, pistol_ammo_count, shotgun_ammo_count
    
    shotgunAmount = bot.ammo (2)
    print ("shotgunAmount = ", shotgunAmount)
    if shotgunAmount > 0:
        bot.reloadWeapon ()
        noMoreShotgunAmmo = False
        shotgun_ammo_count = 0
        return True
    else:
        noMoreShotgunAmmo = True
        if bot.inventoryWeapon (1) == True:
            bot.changeWeapon (1)
            holdingPistol = True
            holdingShotgun = False
        return False
          
    pistolAmount = bot.ammo (1)
    print ("pistolAmount = ", pistolAmount)
    if pistolAmount > 0:
        bot.reloadWeapon ()
        print ("test1")
        noMorePistolAmmo = False
        pistol_ammo_count = 0
        print ("test2")
        return True
    else:
        noMorePistolAmmo = True
        if bot.inventoryWeapon (2) == True:
            bot.changeWeapon (2)
            holdingPistol = False
            holdingShotgun = True
        return False
                      
def find_gun_ammo (bot):
    global holdingShotgun, holdingPistol, noMoreShotgunAmmo, noMorePistolAmmo, pistol_ammo_count, shotgun_ammo_count
    
    if holdingShotgun == True:
        get_shotgun_ammo (bot)
        if noMoreShotgunAmmo == True:
            bot.dropWeapon ()
            holdingShotgun == False      
            get_shotgun (bot)
            if bot.inventoryWeapon (2) == True:
                bot.changeWeapon (2)
                holdingShotgun = True
                shotgun_ammo_count = 0
            
    elif holdingPistol == True:
        get_pistol_ammo (bot)
        if noMorePistolAmmo == True:
            bot.dropWeapon ()
            holdingPistol == False      
            get_pistol (bot)
            if bot.inventoryWeapon (1) == True:
                bot.changeWeapon (1)
                holdingPistol == True
                pistol_ammo_count = 0
    
    if holdingShotgun == True or holdingPistol == True:
        return True
    else:
        return False
    
   
def surrender (bot, you):
    goVisible ()
    print ("\n")
    print ("\n")
    print ("\n")
    print("IT SHOULD BE WORKING!!!!!")
    print ("\n")
    print ("\n")
    print ("\n")
    print ("\n")
    bot = moveTowardsNoChecks (bot, you)
    bot.select (["move"])
    print ("bot has no more ammo and gives up")
    for weapon in weaponInventory ():
        bot.changeWeapon (weapon)
        time.sleep (3)
        print ("I SURRENDER")
        bot.dropWeapon ()
        print ("Please dont hurt me")
        time.sleep (3)
    
def detection (bot, you):
    bot.reset ()
    x = True
    if not is_close_doom3_detect (bot.getpos (me), bot.getpos (you)):
            x = False
    return x

doommarine = -2  # default unset value - which will yield an
                 # error if sent up to the server

def botMain (bot):
    global me, detectedCheck
    print("success!  python doom marine is alive")

    print("trying to get my id...", end=' ')
    me = bot.me ()
    print("yes")
    print("the python marine id is", me)

    pos = bot.getpos (me)
    pen = bot.d2pv (pos)
    print ("pos = ", pos, "pen coords = ", pen)
    
    print("human player id is", end=' ')
    you = findYou ()
    print (you)
    print ("you =", you)
    
    surrenderCheck = False
    
    while True:
        x = healthCheck ()
        while surrenderCheck == True:
            print("surrender is starting!!!!!")
            surrender (bot, you)
            print("surrender is ending!!!!!") 
            
        detectedCheck = detection (bot, you)                     
        if x == 100 and detectedCheck == False:
            print("patrolling is starting!!!!!")
            patrolling (bot, you)
            print("patrolling is ending!!!!!")
            
        elif x < 100 or detectedCheck == True:
            goInvisible ()
            bot.reset()
            
            print("fire_guns is starting!!!!!")
            ammoInGuns = fire_guns (bot, you)
            print("fire_guns is ending!!!!!")
            
            if ammoInGuns == False:            
                bot.reset()
                
                print("gun_reload_or_change is starting!!!!!")
                ammoInGuns = gun_reload_or_change ()
                print("gun_reload_or_change is ending!!!!!")
                
                if ammoInGuns == False: 
                    bot.reset
                    
                    print("find_gun_ammo is starting!!!!!")
                    y = find_gun_ammo (bot)
                    print("find_gun_ammo is ending!!!!!")

                    if y == False:
                        print("surrenderCheck is starting!!!!!")
                        surrenderCheck = True
                        print("surrenderCheck is ending!!!!!")
                else:
                    continue
            else:
                continue
            
      
    print ("finishing now")
    sys.exit (0)

if len (sys.argv) > 1:
    doommarine = int (sys.argv[1])

#
#  much safer when developing to keep bot global to
#  ensure a single global bot is created.
#
bot = botlib.bot ("localhost", "python_doommarine %d" % (doommarine))
execBot (bot, False)

#!/usr/bin/env python3

import botbasic, time, sys, os
import botlib
from chvec import *
import math
import random


debugTowards = True
maxWeapons = 10
gridUnit = 12 * 4 #  chisel unit is 4 feet
healthy = 0
pistol_ammo_count = 0
shotgun_ammo_count = 0
holdingShotgun = False
holdingPistol = False
noMoreShotgunAmmo = False
noMorePistolAmmo = False
noMoreAmmo = False

#
#  printf - keeps C programmers happy :-)
#

def printf (format, *args):
    print(str(format) % args, end=' ')

def walkSquare ():
    bot.forward (100, 100)
    bot.select (["move"])
    bot.left (100, 100)
    bot.select (["move"])
    bot.back (100, 100)
    bot.select (["move"])
    bot.right (100, 100)
    bot.select (["move"])


def runArc (a):
    bot.forward (100, 100)
    bot.turn (a, 1)
    bot.select (["move"])
    bot.select (["turn"])


def circle ():
    while True:
        for a in range (0, 360, 45):
            runArc (a+180)
        time.sleep (5)
        for w in range (0, 10):
            print("attempting to change to weapon", w, end=' ')
            print("dhewm3 returns", bot.changeWeapon (w))
            time.sleep (3)

def testturn (a):
    bot.turn (a, 1)
    bot.select (["turn"])

def sqr (x):
    return x * x

def calcDist (d0, d1):
    p0 = bot.d2pv (d0)
    p1 = bot.d2pv (d1)
    s = subVec (p0, p1)
    return math.sqrt (sqr (s[0]) + sqr (s[1]))

def is_close_doom3 (position1, position2):
    print ("is_close: ", end="")
    print (position1, position2)
    diff = subVec (position1, position2)
    hypot = math.sqrt (sqr (diff[0]) + sqr (diff[1]))
    print ("  result: ", hypot)
    return hypot <= gridUnit * 2

#
#  move_towards - move bot towards position, pos.
#                 pos is penguin tower coordinates.
#

def move_towards (pos, velocity):
    bot.reset ()
    dist = bot.calcnav_pos (pos)
    if dist is None:
        if debugTowards:
            print ("cannot reach", pos, "bot moving randomly")
            quit () # remove this once test is complete
        bot.turn (random.randint (-90, 90), 1)
        bot.select (["turn"])
        bot.forward (velocity, velocity)
        bot.select (["move"])
    else:
        if debugTowards:
            print("distance according to dijkstra is", dist)
        bot.journey_pos (velocity, dist, pos)
        if debugTowards:
            print("finished my journey to", pos)
            print("  I'm at", bot.d2pv (bot.getpos (me)))

def moveTowards (bot, i):
    bot.reset ()
    print("will go and find", i)
    print("I'm currently at", bot.getpos (me), "and", i, "is at", bot.getpos (i))
    ### b.face_position (b.getpos (i))
    ### return b
    dest = bot.d2pv (bot.getpos (i))
    if debugTowards:
        print("bot is at", bot.d2pv (bot.getpos (me)))
        print("dest is at", dest)
    while not is_close_doom3 (bot.getpos (me), bot.getpos (i)):
        dest = bot.d2pv (bot.getpos (i))
        d = bot.calcnav (i)
        if debugTowards:
            print("object", i, "is", d, "units away at pen coord", dest)
        if d is None:
            if debugTowards:
                print("cannot reach, randomly moving", i)
            # do something and move elsewhere
            bot.turn (random.randint (-90, 90), 1)
            bot.select (["turn"])
            bot.forward (100, random.randint (8, 12))
            bot.select (["move"])
            return bot
        else:
            if debugTowards:
                print("distance according to dijkstra is", d)
            bot.journey (100, d, bot.d2pv (bot.getpos (i)), i)
            if debugTowards:
                print("finished journey (...", i, ")")
                print("  result is that I'm currently at", bot.getpos (me), "and", i, "is at", bot.getpos (i))
                print("      penguin tower coords I'm at", bot.d2pv (bot.getpos (me)), "and", i, "is at", dest)
    # and face the object
    bot.face (i)
    return bot


def findAll (bot):
    for i in bot.allobj ():
        print("the location of python bot", me, "is", bot.getpos (me))
        if i != me:
            bot.aim (i)
            bot = moveTowards (bot, i)
            time.sleep (5)

def findYou ():
    for i in bot.allobj ():
        if i != bot.me ():
            return i


def antiClock ():
    print("finished west, north, east, south")
    print("west, north, east, south diagonal")
    for v in [[1, 1], [-1, 1], [-1, -1], [1, -1]]:
        print("turning", end=' ')
        bot.turnface (v, 1)
        bot.sync ()
        print("waiting")
        time.sleep (10)
        print("next")
        bot.reset ()


def clock ():
    print("finished west, north, east, south")
    print("west, north, east, south diagonal")
    for v in [[1, 1], [1, -1], [-1, -1], [-1, 1]]:
        print("turning", end=' ')
        bot.turnface (v, -1)
        bot.sync ()
        print("waiting")
        time.sleep (10)
        print("next")
        bot.reset ()

#
#  test_crouch - make the bot crouch and then jump.
#

def test_crouch_jump (bot):
    bot.reset ()
    bot.stepup (-2, 3*12)
    bot.select (['move'])
    # time.sleep (2)
    bot.stepup (100, 4*12)
    bot.select (['move'])


def crouch_fire (you):
    bot.reset ()
    bot.face (you)
    bot.select (['move'])  # wait until bot has stopped moving
    bot.startFiring ()
    bot.stepup (-2, 4*12)  # crouch
    bot.face (you)
    bot.select (['move'])  # wait the crouch and fire single round to finish
    bot.select (['fire'])
    bot.stopFiring ()
    
def walk_fire (bot, you):
    bot.reset ()
    bot = moveTowards (bot, you)
    bot.face (you)
    bot.select (['move'])  # wait until bot has stopped moving
    goVisible ()
    bot.startFiring ()
    goInvisible ()
    bot.face (you)
    bot.select (['move'])  # wait the crouch and fire single round to finish
    bot.select (['fire'])
    bot.stopFiring ()    

def guard_sentry ():
    me = bot.me ()
    you = findYou ()
    start_pos = bot.d2pv (bot.getpos (me))  # penguin tower coords
    end_pos = addVec (start_pos, [10, 0])  # penguin tower coords
    while True:
        if healthCheck () != 100:
            break
        move_towards (end_pos, 100)
        if healthCheck () != 100:
            break
        bot.turn (180, 1)
        bot.select (["turn"])
        if healthCheck () != 100:
            break
        move_towards (start_pos, 100)
        if healthCheck () != 100:
            break        
        bot.turn (180, 1)
        bot.select (["turn"])
        return


def testVisibility (disappear, disappear_head, water, materialise, materialise_head):
    bot.setvisibilityshader (disappear)  # all players entities use disappear
    bot.setvisibilityshader (disappear_head, ["player2_head"])  #  change the head entity
    bot.visibilityParams ([8])   # run visibility effects for a duration of 8 seconds
    bot.visibilityFlag (True)    # turn on the visibility flag for all player entities.
    bot.flipVisibility ()        # now release all the above info to the renderer
    bot.face (1)                 # turn and face player 1 (human)
    time.sleep (7)             # wait for 7 seconds
    bot.face (1)                 # turn and face player 1 (human)
    bot.setvisibilityshader (water)
    bot.visibilityFlag (True)
    bot.visibilityParams ([3, 3])
    bot.flipVisibility ()        # now release all the above info to the renderer
    bot.face (1)                 # turn and face player 1 (human)
    time.sleep (6)             # wait for 6 seconds
    bot.setvisibilityshader (water)
    bot.visibilityFlag (True)
    bot.visibilityParams ([3, 3])
    bot.flipVisibility ()
    bot.setvisibilityshader (materialise)
    bot.setvisibilityshader (materialise_head, ["player2_head"])
    bot.visibilityParams ([14])
    bot.visibilityFlag (True)
    bot.flipVisibility ()        # now release all the above info to the renderer
    bot.face (1)                 # turn and face player 1 (human)
    time.sleep (14)            # wait for 14 seconds
    bot.visibilityFlag (False)
    bot.flipVisibility ()
    time.sleep (3)             # wait for 3 seconds


def goInvisible ():
    bot.setvisibilityshader ("pulse/melt/model/player")
    bot.visibilityFlag (True)
    bot.visibilityParams ([3, 3])
    bot.flipVisibility ()
    bot.setvisibilityshader ("melt/model/player/green/body2inv")  # all players entities use disappear
    bot.setvisibilityshader ("melt/model/player/green/head2inv", ["player2_head"])  #  change the head entity
    #bot.visibilityParams ([2])   # run visibility effects for a duration of .. seconds
    #bot.visibilityFlag (True)    # turn on the visibility flag for all player entities.
    #bot.flipVisibility ()        # now release all the above info to the renderer

def goVisible ():
    bot.visibilityFlag (False)    # turn on the visibility flag for all player entities.
    bot.flipVisibility ()
#
#  visibilityExamples - some test examples to stress the visibility API.
#

def visibilityExamples ():
    testVisibility ("melt/model/player/green/body2inv",
                    "melt/model/player/green/head2inv",
                    "pulse/melt/model/player",
                    "melt/model/player/green/inv2body",
                    "melt/model/player/green/inv2head")

def weaponInventory ():
    holding_weapons = []
    for weapon in range (0, maxWeapons):
        if bot.inventoryWeapon (weapon):
            holding_weapons += [weapon]
    return holding_weapons

def ammoInventory ():
    holding_ammo = []
    for weapon in range (0, maxWeapons):
        amount = bot.ammo (weapon)
        if amount >= 1:
            holding_ammo += [amount]
    return holding_ammo


def weaponExamples ():
    printf ("bot has the following weapons: ")
    print (weaponInventory ())
    printf ("\n")
    printf ("bot has the following ammo: ")
    print (ammoInventory ())
    printf ("\n")
    for weapon in weaponInventory ():
        bot.changeWeapon (weapon)
        time.sleep (3)
        bot.dropWeapon ()
        time.sleep (3)

def check_movement ():
    me = bot.me ()
    cur_pos_d3 = bot.getpos (me)  # doom3 position
    cur_pos_pen = bot.d2pv (cur_pos_d3)  # penguin tower coords
    print ("main program starting positions for bot")
    print ("  cur_pos_d3 = ", cur_pos_d3, "cur_pos_pen", cur_pos_pen)
    start_pos = bot.d2pv (bot.getpos (me))  # penguin tower coords
    end_pos = addVec (start_pos, [5, -5])  # penguin tower coords
    move_towards (end_pos, 300)
    cur_pos_d3 = bot.getpos (me)  # doom3 position
    cur_pos_pen = bot.d2pv (cur_pos_d3)  # penguin tower coords
    print ("main program after moving 300 units")
    print ("  cur_pos_d3 = ", cur_pos_d3, "cur_pos_pen", cur_pos_pen)
    quit ()

def visit_label (bot, label_list, visited_labels):
    visible_labels = []
    for label in label_list:
        bot.reset ()  # is this necessary?
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        if bot.isvisible (label_entity_no):
            visible_labels += [[label, label_entity_no]]
        if not (label in visited_labels):
            visited_labels[label] = [[label, label_entity_no, 0]]
            print ("moving towards a label:", label)
            bot = moveTowards (bot, label_entity_no)
            return bot, False, visited_labels
    return bot, True, visited_labels


def execBot (bot, useExceptions = True):
    if useExceptions:
        try:
            botMain (bot)
        except:
            print ("bot was killed, or script terminated")
            return
    else:
        botMain (bot)

def healthCheck ():
    global healthy
    bot.reset ()
    healthy = bot.health ()
    return healthy    

def walking (bot, you):
    """
    label_list = bot.get_label_list ()  # obtains a list of label names from the pen map
    print ("bot has found these labels in the map:", label_list)
    visited_labels = {}
    finished = False
    while not finished:
        if healthCheck () != 100:
            break
        bot, finished, visited_labels = visit_label (bot, label_list, visited_labels)
        print ("bot has found these labels in the map:", label_list)
        if healthCheck () != 100:
            break"""
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check1 = "A"
        check2 = "B"
        check3 = "C"
        check4 = "D"
        if label != check1 and label != check2 and label != check3 and label != check4:
            print ("label matches check!")
            if healthCheck () != 100:
                break
            bot = moveTowards (bot, label_entity_no)
            print ("Moving towards pistol ammo!")
            if healthCheck () != 100:
                break
            
            
            
def reload ():
    bot.reloadWeapon ()
    bot.select (['reload'])

def get_pistol_ammo (bot):
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "B"
        if label == check:
            print ("label matches check!")
            bot = moveTowards (bot, label_entity_no)
            print ("Moving towards pistol ammo!")
            break

def get_pistol (bot):
    global pistol_ammo_count
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "A"
        if label == check:
            print ("label matches check!")
            bot = moveTowards (bot, label_entity_no)
            print ("Moving towards pistol ammo!")
            pistol_ammo_count = 0
            break
    
def get_shotgun (bot):
    global shotgun_ammo_count
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "C"
        if label == check:
            print ("label matches check!")
            bot = moveTowards (bot, label_entity_no)
            print ("Moving towards shotgun!")
            shotgun_ammo_count = 0
            break
    
def get_shotgun_ammo (bot):
    label_list = bot.get_label_list ()
    for label in label_list:
        bot.reset ()  # Yes the cache needs to clear so new data can be obtained
        label_entity_map = bot._cache.getEntityNo ("label", label)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        check = "D"
        if label == check:
            print ("label matches check!")
            bot = moveTowards (bot, label_entity_no)
            print ("Moving towards shotgun ammo!")
            break

def gun_check (bot, you):
    global pistol_ammo_count, shotgun_ammo_count, holdingShotgun, holdingPistol
    
    if shotgun_ammo_count < 8:
        bot.changeWeapon (2)
        holdingShotgun = True
        holdingPistol = False
        walk_fire (bot, you)
        shotgun_ammo_count += 1
        print ("shotgun_ammo_count = ", shotgun_ammo_count)
            
    elif pistol_ammo_count < 12:
        bot.changeWeapon (1)
        holdingShotgun = False
        holdingPistol = True
        walk_fire (bot,you)
        pistol_ammo_count += 1
        print ("pistol_ammo_count = ", pistol_ammo_count)
            
    else:
        return False
    
def gun_reload_or_change (you):
    global holdingShotgun, holdingPistol, noMoreShotgunAmmo, noMorePistolAmmo, noMoreAmmo, pistol_ammo_count, shotgun_ammo_count
    
    if holdingShotgun == True:
        shotgunAmount = 0 #bot.ammo (2)
        print ("shotgunAmount = ", shotgunAmount)
        if shotgunAmount > 0:
            reload ()
            noMoreShotgunAmmo = False
            shotgun_ammo_count = 0
            return True
        else:
            noMoreShotgunAmmo = True
            if bot.inventoryWeapon (1) == True:
                bot.changeWeapon (1)
                holdingPistol = True
                holdingShotgun = False
            return False

            
    elif holdingPistol == True:
        pistolAmount = 0#bot.ammo (1)
        print ("pistolAmount = ", pistolAmount)
        if pistolAmount > 0:
            reload ()
            noMorePistolAmmo = False
            pistol_ammo_count = 0
            return True
        else:
            noMorePistolAmmo = True
            if bot.inventoryWeapon (2) == True:
                bot.changeWeapon (2)
                holdingPistol = False
                holdingShotgun = True
            return False
    else:
        print ("isnt holding shotgun or pistol")
        bot.changeWeapon (2)
        holdingShotgun = True
        

def find_gun_ammo (bot, you):
    global holdingShotgun, holdingPistol, noMoreShotgunAmmo, noMorePistolAmmo, pistol_ammo_count, shotgun_ammo_count
    
    if holdingShotgun == True:
        get_shotgun_ammo (bot)
        if noMoreShotgunAmmo == True:
            bot.dropWeapon ()
            holdingShotgun == False      
            get_shotgun (bot)
            if bot.inventoryWeapon (2) == True:
                bot.changeWeapon (2)
                holdingShotgun = True
                shotgun_ammo_count = 0
            
    elif holdingPistol == True:
        get_pistol_ammo (bot)
        if noMorePistolAmmo == True:
            bot.dropWeapon ()
            holdingPistol == False      
            get_pistol (bot)
            if bot.inventoryWeapon (1) == True:
                bot.changeWeapon (1)
                holdingPistol == True
                pistol_ammo_count = 0
    
    if holdingShotgun == True or holdingPistol == True:
        return True
    else:
        return False
    
   
def surrender (bot, you):
    goVisible ()
    print ("\n")
    print ("\n")
    print ("\n")
    print("IT SHOULD BE WORKING!!!!!")
    print ("\n")
    print ("\n")
    print ("\n")
    print ("\n")
    bot = moveTowards (bot, you)
    bot.select (["move"])
    print ("bot has no more ammo and gives up")
    for weapon in weaponInventory ():
        bot.changeWeapon (weapon)
        time.sleep (3)
        print ("I SURRENDER")
        bot.dropWeapon ()
        print ("Please dont hurt me")
        time.sleep (3)

        
doommarine = -2  # default unset value - which will yield an
                 # error if sent up to the server
                 
def get_label_entity (label_name):
    return bot._cache.getEntityNo ("label", label_name)

def botMain (bot):
    global me, pistol_ammo_count, shotgun_ammo_count, holdingShotgun, holdingPistol, noMoreShotgunAmmo, noMorePistolAmmo, noMoreAmmo
    print("success!  python doom marine is alive")

    print("trying to get my id...", end=' ')
    me = bot.me ()
    print("yes")
    print("the python marine id is", me)

    pos = bot.getpos (me)
    pen = bot.d2pv (pos)
    print ("pos = ", pos, "pen coords = ", pen)
    
    print("human player id is", end=' ')
    you = findYou ()
    print (you)
    print ("you =", you)
    surrenderCheck = False
    bot.changeWeapon (2)

    while True:
        x = healthCheck ()             
        if x == 100 and surrenderCheck == False:     
            walking (bot, you)
        elif x < 100 and surrenderCheck == False:
            goInvisible ()
            bot.reset()
            ammoInGuns = gun_check (bot, you)      
            if ammoInGuns == False:
                bot.reset()
                ammoInGuns = gun_reload_or_change (you)
                y = find_gun_ammo (bot, you)
                if y == False:
                    surrenderCheck = True
        else:
            surrender (bot, you)
      
    print ("finishing now")
    sys.exit (0)

if len (sys.argv) > 1:
    doommarine = int (sys.argv[1])

#
#  much safer when developing to keep bot global to
#  ensure a single global bot is created.
#
bot = botlib.bot ("localhost", "python_doommarine %d" % (doommarine))
execBot (bot, False)

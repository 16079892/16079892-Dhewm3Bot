#!/usr/bin/env python3

import botbasic, time, sys, os
import botlib
from chvec import *
import math
import random

debugTowards = True
maxWeapons = 10
gridUnit = 12 * 4 #  chisel unit is 4 feet


#
#  printf - keeps C programmers happy :-)
#

def printf (format, *args):
    print(str(format) % args, end=' ')


def walkSquare ():
    steve.forward (100, 100)
    steve.select (["move"])
    steve.left (100, 100)
    steve.select (["move"])
    steve.back (100, 100)
    steve.select (["move"])
    steve.right (100, 100)
    steve.select (["move"])


def runArc (a):
    steve.forward (100, 100)
    steve.turn (a, 1)
    steve.select (["move"])
    steve.select (["turn"])


def circle ():
    while True:
        for a in range (0, 360, 45):
            runArc (a+180)
        time.sleep (5)
        for w in range (0, 10):
            print("attempting to change to weapon", w, end=' ')
            print("dhewm3 returns", steve.changeWeapon (w))
            time.sleep (3)

def testturn (a):
    steve.turn (a, 1)
    steve.select (["turn"])

def sqr (x):
    return x * x

def calcDist (d0, d1):
    p0 = steve.d2pv (d0)
    p1 = steve.d2pv (d1)
    s = subVec (p0, p1)
    return math.sqrt (sqr (s[0]) + sqr (s[1]))

def is_close_doom3 (position1, position2):
    print ("is_close: ", end="")
    print (position1, position2)
    diff = subVec (position1, position2)
    hypot = math.sqrt (sqr (diff[0]) + sqr (diff[1]))
    print ("  result: ", hypot)
    return hypot <= gridUnit * 2

#
#  moveTowards - move towards object, i.
#

def moveTowards (i):
    steve.reset ()
    print("will go and find", i)
    #print("I'm currently at", bot.getpos (me), "and", i, "is at", bot.getpos (i))
    """
    if not equVec (bot.d2pv (bot.getpos (me)), [12, 9]):
        print "failed to find getpos at 12, 9 for python"
    if not equVec (bot.d2pv (bot.getpos (i)), [40, 3]):
        print "failed to find getpos at 40, 3 for player"
    """
    if debugTowards:
        print("bot is at", steve.d2pv (steve.getpos (me)))
        print("you are at", steve.d2pv (steve.getpos (i)))
    d = steve.calcnav (i)
    if debugTowards:
        print("object", i, "is", d, "units away")
    if d is None:
        if debugTowards:
            print("cannot reach", i)
        steve.turn (90, 1)
        steve.select (["turn"])
        steve.forward (100, 10)
        steve.select (["move"])
    else:
        if debugTowards:
            print("distance according to dijkstra is", d)
        steve.journey (100, d, i)
        if debugTowards:
            print("finished my journey to", i)
            print("  result is that I'm currently at", steve.getpos (me), "and", i, "is at", steve.getpos (i))
            print("      penguin tower coords I'm at", steve.d2pv (steve.getpos (me)), "and", i, "is at", steve.d2pv (steve.getpos (i)))


#
#  move_towards - move bot towards position, pos.
#                 pos is penguin tower coordinates.
#

def move_towards (pos, velocity):
    steve.reset ()
    dist = steve.calcnav_pos (pos)
    if dist is None:
        if debugTowards:
            print ("cannot reach", pos, "bot moving randomly")
            quit () # remove this once test is complete
        steve.turn (random.randint (-90, 90), 1)
        steve.select (["turn"])
        steve.forward (velocity, velocity)
        steve.select (["move"])
    else:
        if debugTowards:
            print("distance according to dijkstra is", dist)
        steve.journey_pos (velocity, dist, pos)
        if debugTowards:
            print("finished my journey to", pos)
            print("  I'm at", steve.d2pv (steve.getpos (me)))

def moveTowards2 (steve, i):
    steve.reset ()
    print("will go and find", i)
    print("I'm currently at", steve.getpos (me), "and", i, "is at", steve.getpos (i))
    ### b.face_position (b.getpos (i))
    ### return b
    dest = steve.d2pv (steve.getpos (i))
    if debugTowards:
        print("steve is at", steve.d2pv (steve.getpos (me)))
        print("dest is at", dest)
    while not is_close_doom3 (steve.getpos (me), steve.getpos (i)):
        dest = steve.d2pv (steve.getpos (i))
        d = steve.calcnav (i)
        if debugTowards:
            print("object", i, "is", d, "units away at pen coord", dest)
        if d is None:
            if debugTowards:
                print("cannot reach, randomly moving", i)
            # do something and move elsewhere
            steve.turn (random.randint (-90, 90), 1)
            steve.select (["turn"])
            steve.forward (100, random.randint (8, 12))
            steve.select (["move"])
            return steve
        else:
            if debugTowards:
                print("distance according to dijkstra is", d)
            steve.journey (100, d, steve.d2pv (steve.getpos (i)), i)
            if debugTowards:
                print("finished journey (...", i, ")")
                print("  result is that I'm currently at", steve.getpos (me), "and", i, "is at", steve.getpos (i))
                print("      penguin tower coords I'm at", steve.d2pv (steve.getpos (me)), "and", i, "is at", dest)
    # and face the object
    steve.face (i)
    return steve


def findAll ():
    for i in steve.allobj ():
        print("the location of python bot", me, "is", steve.getpos (me))
        if i != me:
            steve.aim (i)
            moveTowards (i)
            time.sleep (5)

def findYou ():
    for i in steve.allobj ():
        if i != steve.me ():
            return i


def antiClock ():
    print("finished west, north, east, south")
    print("west, north, east, south diagonal")
    for v in [[1, 1], [-1, 1], [-1, -1], [1, -1]]:
        print("turning", end=' ')
        steve.turnface (v, 1)
        steve.sync ()
        print("waiting")
        time.sleep (10)
        print("next")
        steve.reset ()


def clock ():
    print("finished west, north, east, south")
    print("west, north, east, south diagonal")
    for v in [[1, 1], [1, -1], [-1, -1], [-1, 1]]:
        print("turning", end=' ')
        steve.turnface (v, -1)
        steve.sync ()
        print("waiting")
        time.sleep (10)
        print("next")
        steve.reset ()

#
#  test_crouch - make the bot crouch and then jump.
#

def test_crouch_jump (steve):
    steve.reset ()
    steve.stepup (-2, 3*12)
    steve.select (['move'])
    # time.sleep (2)
    steve.stepup (100, 4*12)
    steve.select (['move'])


def crouch_fire (you):
    steve.reset ()
    steve.face (you)
    steve.changeWeapon (1)  # pistol
    steve.face (you)
    # bot.select (['move'])  # wait until bot has stopped moving
    steve.start_firing ()
    steve.stepup (-2, 4*12)  # crouch
    steve.face (you)
    steve.select (['move'])  # wait the crouch and fire single round to finish
    steve.select (['fire'])
    steve.stop_firing ()
    steve.reload_weapon ()


#
#
#

def guard_sentry ():
    me = steve.me ()
    you = findYou ()
    start_pos = steve.d2pv (steve.getpos (me))  # penguin tower coords
    end_pos = addVec (start_pos, [10, 0])  # penguin tower coords
    while True:
        move_towards (end_pos, 100)
        steve.turn (180, 1)
        steve.select (["turn"])
        crouch_fire (you)
        time.sleep (1)  # --fixme-- should check for activity!
        move_towards (start_pos, 100)
        steve.turn (180, 1)
        steve.select (["turn"])
        crouch_fire (you)
        time.sleep (1)  # --fixme-- should check for activity!


def testVisibility (disappear, disappear_head, water, materialise, materialise_head):
    steve.setvisibilityshader (disappear)  # all players entities use disappear
    steve.setvisibilityshader (disappear_head, ["player2_head"])  #  change the head entity
    steve.visibilityParams ([8])   # run visibility effects for a duration of 8 seconds
    steve.visibilityFlag (True)    # turn on the visibility flag for all player entities.
    steve.flipVisibility ()        # now release all the above info to the renderer
    steve.face (1)                 # turn and face player 1 (human)
    time.sleep (7)             # wait for 7 seconds
    steve.face (1)                 # turn and face player 1 (human)
    steve.setvisibilityshader (water)
    steve.visibilityFlag (True)
    steve.visibilityParams ([3, 3])
    steve.flipVisibility ()        # now release all the above info to the renderer
    steve.face (1)                 # turn and face player 1 (human)
    time.sleep (6)             # wait for 6 seconds
    steve.setvisibilityshader (water)
    steve.visibilityFlag (True)
    steve.visibilityParams ([3, 3])
    steve.flipVisibility ()
    steve.setvisibilityshader (materialise)
    steve.setvisibilityshader (materialise_head, ["player2_head"])
    steve.visibilityParams ([14])
    steve.visibilityFlag (True)
    steve.flipVisibility ()        # now release all the above info to the renderer
    steve.face (1)                 # turn and face player 1 (human)
    time.sleep (14)            # wait for 14 seconds
    steve.visibilityFlag (False)
    steve.flipVisibility ()
    time.sleep (3)             # wait for 3 seconds


def goInvisible ():
    steve.setvisibilityshader ("pulse/melt/model/player")
    steve.visibilityFlag (True)
    steve.visibilityParams ([3, 3])
    steve.flipVisibility ()
    steve.setvisibilityshader ("melt/model/player/green/body2inv")  # all players entities use disappear
    steve.setvisibilityshader ("melt/model/player/green/head2inv", ["player2_head"])  #  change the head entity
    steve.visibilityParams ([2])   # run visibility effects for a duration of .. seconds
    steve.visibilityFlag (True)    # turn on the visibility flag for all player entities.
    steve.flipVisibility ()        # now release all the above info to the renderer



#
#  visibilityExamples - some test examples to stress the visibility API.
#

def visibilityExamples ():
    testVisibility ("melt/model/player/green/body2inv",
                    "melt/model/player/green/head2inv",
                    "pulse/melt/model/player",
                    "melt/model/player/green/inv2body",
                    "melt/model/player/green/inv2head")

def weaponInventory ():
    holding_weapons = []
    for weapon in range (0, maxWeapons):
        if steve.inventoryWeapon (weapon):
            holding_weapons += [weapon]
    return holding_weapons

def ammoInventory ():
    holding_ammo = []
    for weapon in range (0, maxWeapons):
        amount = steve.ammo (weapon)
        if amount >= 1:
            holding_ammo += [amount]
    return holding_ammo


def weaponExamples ():
    printf ("bot has the following weapons: ")
    print (weaponInventory ())
    printf ("\n")
    printf ("bot has the following ammo: ")
    print (ammoInventory ())
    printf ("\n")
    for weapon in weaponInventory ():
        steve.changeWeapon (weapon)
        time.sleep (3)
        steve.dropWeapon ()
        time.sleep (3)


#
#
#

def check_movement ():
    me = steve.me ()
    cur_pos_d3 = steve.getpos (me)  # doom3 position
    cur_pos_pen = steve.d2pv (cur_pos_d3)  # penguin tower coords
    print ("main program starting positions for bot")
    print ("  cur_pos_d3 = ", cur_pos_d3, "cur_pos_pen", cur_pos_pen)
    start_pos = steve.d2pv (steve.getpos (me))  # penguin tower coords
    end_pos = addVec (start_pos, [5, -5])  # penguin tower coords
    move_towards (end_pos, 300)
    cur_pos_d3 = steve.getpos (me)  # doom3 position
    cur_pos_pen = steve.d2pv (cur_pos_d3)  # penguin tower coords
    print ("main program after moving 300 units")
    print ("  cur_pos_d3 = ", cur_pos_d3, "cur_pos_pen", cur_pos_pen)
    quit ()

def visit_label (steve, label_list, visited_labels):
    visible_labels = []
    for label in label_list:
        steve.reset ()  # is this necessary?
        label_entity_map = steve._cache.getEntityNo ("label", label)
        label_entity_no = steve._cache._basic.mapToRunTimeEntity (label_entity_map)
        if steve.isvisible (label_entity_no):
            visible_labels += [[label, label_entity_no]]
        if not (label in visited_labels):
            visited_labels[label] = [[label, label_entity_no, 0]]
            print ("moving towards a label:", label)
            steve = moveTowards2 (steve, label_entity_no)
            return steve, False, visited_labels
    return steve, True, visited_labels


def execBot (steve, useExceptions = True):
    if useExceptions:
        try:
            botMain (steve)
        except:
            print ("bot was killed, or script terminated")
            return
    else:
        botMain (steve)


"""def botMain ():
    global me
    print ("success!  python doom marine is alive")

    printf ("trying to get my id...")
    me = bot.me ()
    printf ("yes\n")
    printf ("the python marine id is: %d\n", me)

    pos = bot.getpos (me)
    pen = bot.d2pv (pos)
    print ("pos = ", pos, "pen coords =", pen)
    print ("getselfentitynames =", bot.getselfentitynames ())

    check_movement ()
    # goInvisible ()
    while True:
        weaponExamples ()
        visibilityExamples ()
        # guard_sentry ()
        # findAll ()


doommarine = -2  # default unset value - which will yield an
                 # error if sent up to the server"""
def get_label_entity (label_name):
    return steve._cache.getEntityNo ("label", label_name)

def botMain (steve):
    global me
    print("success!  python doom marine is alive")

    print("trying to get my id...", end=' ')
    me = steve.me ()
    print("yes")
    print("the python marine id is", me)

    pos = steve.getpos (me)
    pen = steve.d2pv (pos)
    print ("pos = ", pos, "pen coords = ", pen)
    
    print("human player id is", end=' ')
    you = findYou ()
    print (you)
    ###
    #    an ugly hack to test entity label lookup
    ###
    #label_entity_no = b._cache.getEntityNo ("label", "the_ammo_loc")
    #print ("entity number of label =", label_entity_no)
    #print ("entity position =", b._cache.getEntityPos (label_entity_no))
    #^^^^^^^^^these dont work!!!!^^^^^^
    #label_A = b.cache.getEntityNo ("label", "A")
    #label_B = b.cache.getEntityNo ("label", "B")
    ###
    #    end of an ugly hack to test entity label lookup
    ###
    """
    while True:
        print("I AM WORKING")
        test_crouch_jump (bot)
        #bot.face (you)
        #moveTowards (you)
    """
    
    label_list = steve.get_label_list ()  # obtains a list of label names from the pen map
    print ("bot has found these labels in the map:", label_list)
    while True:
        print ("\n")
        print ("\n")
        print ("\n")
        print ("BOT HAS FOUND LABELS AND IS MOVING TOWARDS THEM \n")
        print ("\n")
        print ("\n")
        print ("\n")
        print ("\n")
        visited_labels = {}
        finished = False
        while not finished:
            steve, finished, visited_labels = visit_label (steve, label_list, visited_labels)
            print ("moving towards you!")
            steve = moveTowards2 (steve, you)
            time.sleep (10)
            
    """
    while True:
        #bot.face (1)
        #test_crouch_jump (bot)
        #walkSquare ()
        bot = moveTowards (you)
        for label in bot.get_label_list ():
            print ("map label", label)
            label_entity_no = get_label_entity (label)
            print ("runtime entity label", label_entity_no)
            bot._cache.reset ()
            print ("can I see", label_entity_no, "?")
            #if  bot.isvisible (label_entity_no): #Bot claims it can never see entity number even when it should, why wont it work?
            if label_entity_no:     
                print ("yes I can see the label /n /n")
                bot.face (label_entity_no)
                print ("moving towards the label")
                moveTowards (label_entity_no)
                time.sleep (5)
                moveTowards (1)
                dist = bot.calcnav (label_entity_no) #Dijkstra algorithm
                print ("calculating distance")
                print ("DISTANCE IS = ", dist)
                print ("POSISTION IS = ", pos)
                bot.journey (100, dist, pos)  #moves bot using algorithm and will check regulary to ensure its on the right path.
                
            else:
                #x = findYou()
                #crouch_fire (x)
                #clock ()
                #antiClock ()
                #circle ()
                test_crouch_jump (bot) # this is a quick and easy test i can see when I boot up dhewm3 and the bot
                print ("no I cannot /n /n")
                bot.face (1)   # turn towards human player
                #walkSquare ()
                #weaponExamples ()
                #goInvisible ()
                #bot.face (label_entity_no)
                #print ("moving towards the label")
                #moveTowards (label_entity_no)
                #time.sleep (5)
                #moveTowards (1)
                #dist = bot.calcnav ( label_entity_no) #Dijkstra algorithm
                #print ("calculating distance")
                #print ("DISTANCE IS = ", dist)
                #print ("POSISTION IS = ", pos)
                #bot.journey_pos (100, dist, pos)
                #guard_sentry (b)
                #test = findYou (b)
                #print ("this is test", test)
                #moveTowards (test)
                #print (me, "this is me pos")
                #move_towards (b, me, 10)
                #dist = b.calcnav (label_entity_no)
                #b.journey (100, dist, pos)         
        time.sleep (1)
        # findAll ()
        # guard_sentry (b)
    """
    """
    while True:
        for label in ["C"]:
            print ("label", label)
            pos = bot.getpos (get_label_entity (label))
            print ("label", label)
            dist = bot.calcnav_pos (label)
            bot.journey (100, dist, pos)
        bot.turn (me, 1)
        #moveTowards (you)
        bot.sync ()
        bot.reset ()
    """
    print ("finishing now")
    sys.exit (0)

if len (sys.argv) > 1:
    doommarine = int (sys.argv[1])

#
#  much safer when developing to keep bot global to
#  ensure a single global bot is created.
#
#doommarine = 0
steve = botlib.bot ("localhost", "python_doommarine %d" % (doommarine))
execBot (steve, False)

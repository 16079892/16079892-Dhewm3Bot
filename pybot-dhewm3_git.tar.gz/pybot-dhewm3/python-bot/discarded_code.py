 #bot.reset ()
        #moveTowards (you)
        #healthy = bot.health ()
        #if healthy == 100:
            #print ("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", healthy)
        #if healthy != 100:   
         #   print ("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", healthy) 
          #  test_crouch_jump (bot) 
        #walking (bot, you)
    ###
    #    an ugly hack to test entity label lookup
    ###
    #label_entity_no = b._cache.getEntityNo ("label", "the_ammo_loc")
    #print ("entity number of label =", label_entity_no)
    #print ("entity position =", b._cache.getEntityPos (label_entity_no))
    #^^^^^^^^^these dont work!!!!^^^^^^
    #label_A = b.cache.getEntityNo ("label", "A")
    #label_B = b.cache.getEntityNo ("label", "B")
    ###
    #    end of an ugly hack to test entity label lookup
    ###
    #ahbs = bot.health ()
    #print ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX = ", ahbs)
    """
    while True:
        posH = bot.getpos (you)
        print ("pos =", posH)
        #print ("pos = ", pos, "pen coords = ", pen)
        #time.sleep(0.2)
        
        label_entity_map = bot._cache.getEntityNo ("label", you)
        label_entity_no = bot._cache._basic.mapToRunTimeEntity (label_entity_map)
        print ("\n")
        print ("\n")
        print ("\n")
        print ("\n")
        print ("you = ", you, "     label_entity_map = ", label_entity_map, "     label_entity_no = ", label_entity_no)
        print ("\n")
        print ("\n")
        print ("\n")
        print ("\n")    
        if bot.isvisible (label_entity_no):
            print ("\n")
            print ("\n")
            print ("\n")
            print ("IS VIS IS WORKING \n")
            print ("\n")
            print ("\n")
            print ("\n")
            print ("\n")
        else:
            print ("\n")
            print ("\n")
            print ("\n")
            print ("NO\n")
            print ("\n")
            print ("\n")
            print ("\n")
            print ("\n")        
     #   print ("you =", you)
      #  print("the python marine id is", me)
        #bot = healthCheck ()
        #time.sleep(1)
        #ahbs = bot.health ()
        #print("I AM WORKING")
        #guard_sentry ()
        #test_crouch_jump (bot)
        #ahbs = bot.health ()
        #print (ahbs)
        #if ahbs == 100:
         #   print ("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", ahbs)
        #elif ahbs < 100:    
         #   test_crouch_jump (bot)    
        #bot.face (you)
        #moveTowards (you)
        """
          
    """
    while True:
        #bot.face (1)
        #test_crouch_jump (bot)
        #walkSquare ()
        bot = moveTowards (you)
        for label in bot.get_label_list ():
            print ("map label", label)
            label_entity_no = get_label_entity (label)
            print ("runtime entity label", label_entity_no)
            bot._cache.reset ()
            print ("can I see", label_entity_no, "?")
            #if  bot.isvisible (label_entity_no): #Bot claims it can never see entity number even when it should, why wont it work?
            if label_entity_no:     
                print ("yes I can see the label /n /n")
                bot.face (label_entity_no)
                print ("moving towards the label")
                moveTowards (label_entity_no)
                time.sleep (5)
                moveTowards (1)
                dist = bot.calcnav (label_entity_no) #Dijkstra algorithm
                print ("calculating distance")
                print ("DISTANCE IS = ", dist)
                print ("POSISTION IS = ", pos)
                bot.journey (100, dist, pos)  #moves bot using algorithm and will check regulary to ensure its on the right path.
                
            else:
                #x = findYou()
                #crouch_fire (x)
                #clock ()
                #antiClock ()
                #circle ()
                test_crouch_jump (bot) # this is a quick and easy test i can see when I boot up dhewm3 and the bot
                print ("no I cannot /n /n")
                bot.face (1)   # turn towards human player
                #walkSquare ()
                #weaponExamples ()
                #goInvisible ()
                #bot.face (label_entity_no)
                #print ("moving towards the label")
                #moveTowards (label_entity_no)
                #time.sleep (5)
                #moveTowards (1)
                #dist = bot.calcnav ( label_entity_no) #Dijkstra algorithm
                #print ("calculating distance")
                #print ("DISTANCE IS = ", dist)
                #print ("POSISTION IS = ", pos)
                #bot.journey_pos (100, dist, pos)
                #guard_sentry (b)
                #test = findYou (b)
                #print ("this is test", test)
                #moveTowards (test)
                #print (me, "this is me pos")
                #move_towards (b, me, 10)
                #dist = b.calcnav (label_entity_no)
                #b.journey (100, dist, pos)         
        time.sleep (1)
        # findAll ()
        # guard_sentry (b)
    """
    
    """
    while True:
        for label in ["C"]:
            print ("label", label)
            pos = bot.getpos (get_label_entity (label))
            print ("label", label)
            dist = bot.calcnav_pos (label)
            bot.journey (100, dist, pos)
        bot.turn (me, 1)
        #moveTowards (you)
        bot.sync ()
        bot.reset ()
    """

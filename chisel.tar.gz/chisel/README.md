# chisel
Command line tools to create doom3 maps

Chisel consist of a number of command line tools which
can be used to create really simple doom3 maps.

The programs are:

txt2pen   - convert a txt file into a pen file.

pen2txt   - convert a pen file into a txt file.

txt2map   - convert a pen file into a map file.

pen2map   - convert a pen into a map.

map2bsp   - convert a map into a bsp file.
            (not yet complete)

rndpen    - create a random pen file.
            (not yet available)
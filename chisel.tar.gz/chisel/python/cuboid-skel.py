#!/usr/bin/env python3

from chvec import *


inchesPerUnit = 48   # one ascii position represents this number of inches (4 feet) (so we can see the test cuboid)



#
#  printf - keeps C programmers happy :-)
#

def printf (format, *args):
    print (str(format) % args, end="")


def printBrushdef3 (polygonVertices):
    printf ("""
// automatically created from: tiny.pen
Version 2
// entity 0   (contains all room walls, floors, ceilings, lightblocks)
{
    "classname" "worldspawn"
    "spawnflags" "1"
    "penmap" "tiny.pen"
    // room 1
    // cuboid 1
    {
         brushDef3
         {
""")
    generatePlanes (polygonVertices)
    printf ("""
         }
    }
}
    """)

#
#
#    6 +-----+ 7
#     /|    /|
#  5 +-----+4|
#    | |   | |
#    |0+---|-+ 1
#    |/    |/
#  3 +-----+ 2
#

polygonVertices = [[0, 0, 0],    # vertice 0
                   [0, 1, 0],    # vertice 1
                   [1, 1, 0],    # vertice 2
                   [1, 0, 0],    # vertice 3
                   [1, 1, 1],    # vertice 4
                   [1, 0, 1],    # vertice 5
                   [0, 0, 1],    # vertice 6
                   [0, 1, 1]     # vertice 7
                  ]

#
#  faces - all vertices are ordered according to the right hand rule.
#
faces = [[2, 4, 3, 5],	#front
		 [1, 7, 2, 4],	#right
		 [4, 7, 5, 6],	#top
		 [1, 2, 0, 3],	#bottom
		 [3, 5, 0, 6],	#left
		 [0, 6, 1, 7]]	#back


#
#  crossProduct - return the cross product of a and b.
#                 a x b
#


def crossProduct (a, b):
    assert (len (a) == 3)
    assert (len (b) == 3)
    return [a[1] * b[2] - (b[1] * a[2]),
            a[2] * b[0] - (a[0] * b[2]),
            a[0] * b[1] - (a[1] * b[0])]

def distance (p, a, b, c):
    d = - (p[0] * a + b * p[1] + c * p[2])
    return d

#
#  printPlane -
#

def printPlane (a, b, c, d):
    printf ('             ( %g %g %g %g ) ( ( 0.0078125 0 0.5 ) ( 0 -0.0078125 -1 ) ) "textures/hell/cbrick2b" 0 0 0\n', a, b, c, d)


def calcPlaneEquation (p0, v0, v1):
    a, b, c = crossProduct (v0, v1)
    d = distance (p0, a, b, c)
    return a, b, c, d


def scaleUnit (i):
    return i * inchesPerUnit


def scale2Doom3 (v):
    r = []
    for i in v:
        r += [scaleUnit (i)]
    return r


#
#  printFace - work out the plane equation of the face and print it in doom3 map format.
#

def printFace (polygonVertices, face):
    # left as an exercise for the reader
    v0 = subVec (polygonVertices [face[0]], polygonVertices[face[1]])
    v1 = subVec (polygonVertices [face[1]], polygonVertices[face[2]])
    a, b, c, d = calcPlaneEquation (polygonVertices[face[0]], v0, v1)
    a, b, c = normaliseVec ([a, b, c])
    printPlane (a, b, c, d)


def generatePlanes (polygonVertices):
    for face in faces:
        printFace (polygonVertices, face)


def scaleVertice (vertice, amount):
    v = []
    for value in vertice:
        v += [value * amount]
    return v


def scaleCube (vertices, amount):
    v = []
    for vertice in vertices:
        v += [scaleVertice (vertice, amount)]
    return v


def translateCube (vertices, offset):
    v = []
    for vertice in vertices:
        v += [addVec (vertice, offset)]
    return v


#
#  shearCube - moves the top of the cube by offset.
#

def shearCube (vertices, offset):
    v = []
    for vertice in vertices[:4]:
        v += [vertice]
    for vertice in vertices[4:]:
        v += [addVec (vertice, offset)]
    return v


printBrushdef3 (translateCube (scaleCube (polygonVertices, 5), [0, 10, 0]))
